package de.hsh.steam.application;

import java.io.Serializable;

public enum Streamingprovider implements Serializable{
	Netflix, AmazonPrime, Skye;

}
