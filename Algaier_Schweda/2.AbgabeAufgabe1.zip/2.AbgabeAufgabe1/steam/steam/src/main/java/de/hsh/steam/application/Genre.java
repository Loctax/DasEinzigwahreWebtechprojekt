package de.hsh.steam.application;

import java.io.Serializable;

public enum Genre implements Serializable {
	
	Thriller, ScienceFiction, Drama, Action, Comedy, Documentary;

}
