Mitglieder:
Maximilian Algaier 1433641
Melisa Schweda 1530259

Vieles gemeinsam gemacht (discord/ präsenz)
Maxi hat sich auf den Rest-Server spezialisiert 
Melisa hat sich hauptsächlich um HTML und CSS spezialisiert

(Haben je doch die ganze Zeit zusammen programmiert und uns viel gegenseitig unterstützt)
