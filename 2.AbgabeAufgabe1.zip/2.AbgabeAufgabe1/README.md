Mitglieder:
Maximilian Algaier 1433641
Melisa Schweda 1530259

Bisher nur Aufgabe 1, da Probleme mit Rest (wie per Mail abgesprochen)