package de.hsh.steam.services;

import static de.hsh.steam.application.Genre.*;
import de.hsh.steam.application.Rating;
import de.hsh.steam.application.Score;
import de.hsh.steam.application.Series;
import static de.hsh.steam.application.Streamingprovider.*;
import de.hsh.steam.application.User;
import de.hsh.steam.persistence.DataBaseClass;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Userservice {

    private static Map<Long, User> userMap = DataBaseClass.getUser();
    SeriesService s = new SeriesService();

    public Userservice() {

    }

    public List<User> getAllUsers() {
        return new ArrayList<>(userMap.values());
    }

    public User getUser(long id) {
        return userMap.get(id);
    }

    public User addUser(User user) {
        user.setId(userMap.size() + 1);
        userMap.put(user.getId(), user);
        return user;
    }

    public User deleteUser(long id) {
        return userMap.remove(id);
    }

    public List<Series> getUserSeries(long id) {
        return getUser(id).getSeries();
    }

    public List<Series> addUserSeries(long userId, Series series) {
        s.addSeries(series);
        getUser(userId).getSeries().add(series);
        return getUser(userId).getSeries();
    }

    public Rating getRating(long userId, long seriesId) {
        return getUser(userId).ratingOf(s.getSeries(seriesId));

    }
}
