package de.hsh.steam.beans;

import de.hsh.steam.beans.userBean;
import de.hsh.steam.application.Genre;
import de.hsh.steam.application.Score;
import de.hsh.steam.application.Steamservices;
import de.hsh.steam.application.Streamingprovider;
import java.io.Serializable;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

@Named("seriesBean")
@SessionScoped
public class seriesBean implements Serializable {

    @NotNull
    private String title;
    @NotNull
    private Genre genre;
    @Min(1)
    @NotNull
    private int seasons;
    @NotNull
    private Streamingprovider streamer;
    @NotNull
    private Score score = Score.valueOf("unrated");
    private String remark;

    public void setTitle(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }

    public void setGenre(Genre genre) {
        this.genre = genre;
    }

    public Genre getGenre() {
        return genre;
    }

    public void setSeasons(int seasons) {
        this.seasons = seasons;
    }

    public int getSeasons() {
        return seasons;
    }

    public void setStreamer(Streamingprovider streamer) {
        this.streamer = streamer;
    }

    public Streamingprovider getStreamer() {
        return streamer;
    }

    public Score getScore() {
        return score;
    }

    public void setScore(Score score) {
        this.score = score;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String addSeries(userBean userBean) {
        Steamservices facade = new Steamservices().singleton();
        String name = userBean.getStaticName();
        facade.addOrModifySeries(title, seasons, genre, streamer, name, score, remark);
        userBean.setSeriesList(facade.getAllSeriesOfUser(name));
        return "myPageScreen";
    }

}
