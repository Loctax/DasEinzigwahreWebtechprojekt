package de.hsh.steam.beans;

import de.hsh.steam.application.Genre;
import de.hsh.steam.application.Score;
import de.hsh.steam.application.Series;
import de.hsh.steam.application.Steamservices;
import de.hsh.steam.application.Streamingprovider;
import java.io.Serializable;
import java.util.ArrayList;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

import javax.validation.constraints.NotNull;

@Named("userBean")
@SessionScoped
public class userBean implements Serializable {

    @NotNull
    private String name;
    private static String staticName;
    @NotNull
    private String password;
    private String message;
    private String search = null;
    private String searchCat;
    private ArrayList<Series> seriesList;
    String searchUser = "";
    Genre searchGenre = null;
    Streamingprovider searchProvider = null;
    Score searchScore = null;
    String searchTitle;

    public void setSearchTitle(String searchTitle) {
        this.searchTitle = searchTitle;
    }

    public String getSearchTitle() {
        return searchTitle;
    }

    public String getName() {
        return name;
    }

    public static String getStaticName() {
        return staticName;
    }

    public void setName(String name) {
        this.name = name;
        this.staticName = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getSearch() {
        return search;
    }

    public Genre getSearchGenre() {
        return searchGenre;
    }

    public Streamingprovider getSearchProvider() {
        return searchProvider;
    }

    public Score getSearchScore() {
        return searchScore;
    }

    public void setSearch(String search) {
        this.search = search;
    }

    public String getSearchCat() {

        return searchCat;
    }

    public void setSearchCat(String searchCat) {
        this.searchCat = searchCat;
    }

    public String getSearchUser() {

        return searchCat;
    }

    public static void setStaticName(String staticName) {
        userBean.staticName = staticName;
    }

    public void setSearchUser(String searchUser) {
        this.searchUser = searchUser;
    }

    public void setSearchGenre(Genre searchGenre) {
        this.searchGenre = searchGenre;
    }

    public void setSearchProvider(Streamingprovider searchProvider) {
        this.searchProvider = searchProvider;
    }

    public void setSearchScore(Score searchScore) {
        this.searchScore = searchScore;
    }

    public ArrayList<Series> getSeriesList() {
        Steamservices facade = new Steamservices();
        if (seriesList == null) {
            seriesList = facade.getAllSeriesOfUser(name);
        }
        return seriesList;
    }

    public void setSeriesList(ArrayList<Series> seriesList) {
        this.seriesList = seriesList;
    }

    public String login() {
        Steamservices facade = Steamservices.singleton();
        if (facade.login(name, password)) {
            message = "";
            seriesList = facade.getAllSeriesOfUser(name);
            return "myPageScreen";
        } else {
            message = "Die Anmeldedaten sind leider nicht richtig!";
            return "loginscreen";
        }
    }

    public String register() {
        Steamservices facade = Steamservices.singleton();
        if (name.equals("") || password.equals("")) {
            message = "Benutzername oder Passwort dürfen nicht leer sein";
            return "loginscreen";
        }
        if (facade.newUser(name, password)) {
            message = "Sie sind nun mit dem Namen " + name + " registriert";
            return "loginscreen";
        } else {
            message = "Der Name wird leider schon benutzt!";
            return "loginscreen";
        }
    }

    public String logout() {
        return "index";
    }

    public ArrayList<Series> getMovieList() {
        Steamservices facade = Steamservices.singleton();
        return facade.getAllSeriesOfUser(name);
    }

    public String getRating(String title) {
        Steamservices facade = Steamservices.singleton();
        String score;
        if (!searchUser.equals("")) {
            score = facade.getRating(title, searchUser).getScore().toString();
        } else {
            score = facade.getRating(title, name).getScore().toString();
        }

        if (score != null) {
            return score;
        } else {
            return "";
        }
    }

    public String search() {
        Steamservices facade = new Steamservices();
        if (!searchTitle.equals("")) {
            seriesList = facade.getAllSeriesWithTitle(searchTitle);
            seriesList = facade.searchFiltered(name, searchGenre, searchProvider, searchScore, seriesList);
            return "myPageScreen";

        }
        if (searchUser.equals("")) {
            seriesList = facade.search(name, searchGenre, searchProvider, searchScore);
            return "myPageScreen";
        }
        seriesList = facade.search(searchUser, searchGenre, searchProvider, searchScore);
        return "myPageScreen";
    }

    public String getRemark(String title) {
        Steamservices facade = Steamservices.singleton();
        String remark = "";
        if (!searchUser.equals("")) {
            remark = facade.getRating(title, searchUser).getRemark();
        } else {
            remark = facade.getRating(title, name).getRemark();
        }

        if (remark != null) {
            return remark;
        } else {
            return "";
        }

    }
}
